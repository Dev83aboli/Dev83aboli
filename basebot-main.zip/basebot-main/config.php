<?php

$TG_BOT_TOKEN = $_ENV['TG_BOT_TOKEN'];


?>
